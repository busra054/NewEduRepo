﻿SELECT * FROM dbo.Users;
